(() => {
  if (window.__scoutwiseLoaded) return;
  window.__scoutwiseLoaded = true;

  // All Facebook-specific guesses live in this block. Tune them against real pages.
  const RESERVED = new Set(['watch','groups','pages','marketplace','events','friends','gaming','reel','reels','stories','settings','login','help','messages','notifications','bookmarks','search','hashtag','photo','photos','video','videos','share','sharer','dialog','policies','privacy','ads','business','fundraisers','saved','memories','places','jobs','permalink.php','story.php','flx','lite','public','people','login.php','recover','checkpoint','l.php','home.php','composer','live','latest','about']);
  const SUB = new Set(['friends','followers','following','photos','videos','reels']);
  const RULES = [
    ['work', /^(works?|worked|founder|co-?founder|owner|ceo)\b/i],
    ['education', /^(studied|studies|went to|goes to|attended)\b/i],
    ['livesIn', /^lives in\b/i],
    ['from', /^from\b/i],
    ['relationship', /^(single|married|in a relationship|engaged|divorced|widowed)/i],
    ['joined', /^joined\b/i],
    ['followedBy', /^followed by\b/i],
    ['birthday', /^born\b/i],
  ];
  const NOISE = /^(page|intro|about|overview|edit( details)?|see more|see all|add .+|friends|photos|more|posts|reels|mentions|reviews|followers|following|all|·)$/i;
  const NUM = /^\d[\d.,]*\s?[KMB]?(\s+(comments?|shares?|views?|reactions?))?$/i;
  const UI = /^(like|comment|share|reply|follow|send|write a comment…?|most relevant|all reactions:?|·|\d+\s?[smhdwy]|just now|see more|public|sponsored)$/i;
  const MAIL = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;

  const clean = (t) => String(t || '').replace(/[\x00-\x1f\x7f]+/g, ' ').replace(/\s+/g, ' ').trim();
  // Facebook mixes aria-hidden watermark text ("Facebook" repeated, letters followed by U+034F) into the page text.
  const lines = (t) => String(t || '').split('\n').map(clean).filter((l) => l && l !== 'Facebook' && !/\u034f/.test(l));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const num = (txt, re) => ((txt.match(re) || [])[1] || '').trim();

  function profileUrl() {
    const u = new URL(location.href);
    if (!/(^|\.)facebook\.com$/.test(u.hostname)) return null;
    if (u.pathname.replace(/\/$/, '') === '/profile.php') {
      const id = u.searchParams.get('id');
      return id && /^\d+$/.test(id) ? `https://www.facebook.com/profile.php?id=${id}` : null;
    }
    const seg = u.pathname.split('/').filter(Boolean);
    if (!seg.length || seg.length > 2 || RESERVED.has(seg[0].toLowerCase())) return null;
    if (seg[1] && !/^about/i.test(seg[1]) && !SUB.has(seg[1].toLowerCase())) return null;
    return `https://www.facebook.com/${seg[0].toLowerCase()}`;
  }

  // The name comes from the page heading; while Facebook has not drawn it yet, the tab title ("Name | Facebook") is used.
  function nameOf() {
    const bad = /^(notifications|facebook)$/i;
    const h = [...document.querySelectorAll('h1')].map((e) => clean(e.textContent)).find((t) => t && !bad.test(t));
    if (h) return h;
    const t = clean(document.title).replace(/^\(\d+\)\s*/, '').replace(/\s*[|\u2013-]\s*Facebook$/i, '');
    return t && !bad.test(t) ? t : '';
  }

  function detect() {
    const url = profileUrl();
    if (!url) return { isProfile: false };
    const name = nameOf();
    if (!name) return { isProfile: false, loading: true };
    const main = document.querySelector('[role=main]') || document.body;
    const kind = pageKind(main);
    const intro = introLines(main);
    if (kind !== 'page') {
      if (!intro.length && !settled(url)) return { isProfile: false, loading: true };
      return { isProfile: true, kind, author: isAuthor(intro, 'Profile'), url, name };
    }
    if (!intro.length) return { isProfile: false, loading: true };
    return { isProfile: true, kind, author: isAuthor(intro, 'Page'), url, name };
  }

  // The Page category sits right after the "Page" line of the Intro card, e.g. "· Author · History and philosophy".
  // (Not the bio: "Historical Fiction Author telling ..." must not count.)
  function categoryOf(ls, word = 'Page') {
    const i = ls.indexOf(word);
    if (i >= 0 && ls[i + 1] && /^\u00b7/.test(ls[i + 1])) return ls[i + 1];
    return ls.find((l) => new RegExp('^' + word + '\\s*\u00b7').test(l)) || '';
  }
  const isAuthor = (ls, word) => /\bauthors?\b/i.test(categoryOf(ls, word));
  // A creator-mode personal profile reads "Profile \u00b7 Author \u00b7 ..." in the same place. A profile whose Intro is not drawn (or too short to read) is
  // reported as loading for a few seconds, then as not an author.
  let waitUrl = '';
  let waitSince = 0;
  const settled = (url) => {
    if (url !== waitUrl) { waitUrl = url; waitSince = Date.now(); }
    return Date.now() - waitSince > 6000;
  };

  // Pages (businesses, authors, public figures) have Reviews/Mentions tabs; personal profiles have Friends.
  function pageKind(main) {
    const tabs = [...main.querySelectorAll('[role=tab]')].map((t) => clean(t.textContent).toLowerCase());
    return tabs.includes('reviews') || tabs.includes('mentions') ? 'page' : 'profile';
  }

  // "1.3K followers" / "174 following" / "320 friends" from the profile header links (text order independent).
  function countOf(main, kind) {
    for (const a of main.querySelectorAll('a[href]')) {
      let path = '';
      let sk = '';
      try {
        const u = new URL(a.getAttribute('href'), location.href);
        path = u.pathname.replace(/\/$/, '');
        sk = u.searchParams.get('sk') || '';
      } catch { continue; }
      if (!(path.endsWith('/' + kind) || sk === kind)) continue;
      const m = clean(a.innerText || a.textContent).match(/^(\d[\d.,]*\s?[KMB]?)(?=\s*(followers?|following|friends?)\b)/i);
      if (m) return m[1].trim();
    }
    return '';
  }

  function introLines(root) {
    const el = [...root.querySelectorAll('h2,h3,span')].find((e) => e.children.length === 0 && clean(e.textContent) === 'Intro');
    let n = el;
    for (let i = 0; n && i < 16; i++) { // Facebook wraps the label in many nested divs
      n = n.parentElement;
      const ls = n ? lines(n.innerText) : [];
      if (ls.length >= 4) return ls.filter((l) => l !== 'Intro').slice(0, 40);
    }
    return [];
  }

  function parseInfo(ls) {
    const found = {};
    const other = [];
    for (const l of ls) {
      const hit = RULES.find(([, re]) => re.test(l));
      if (hit) (found[hit[0]] = found[hit[0]] || []).push(l);
      else if (l.length > 2 && l.length < 200 && !NOISE.test(l)) other.push(l);
    }
    const out = {};
    for (const k in found) out[k] = found[k].join('; ');
    if (other.length) out.other = [...new Set(other)].slice(0, 40);
    return out;
  }

  const pickBio = (ls) => ls.find((l) => l.length >= 8 && l.length <= 300 && !NOISE.test(l) && !RULES.some(([, re]) => re.test(l))) || '';

  function findEmails(main, ls) {
    const found = new Set();
    ls.join('\n').replace(MAIL, (m) => found.add(m.toLowerCase()));
    main.querySelectorAll('a[href^="mailto:"]').forEach((a) => {
      try {
        const m = decodeURIComponent(a.getAttribute('href').slice(7).split('?')[0]).toLowerCase();
        if (m) found.add(m);
      } catch {}
    });
    return [...found].filter((m) => !/@(facebook|fb|meta)\.com$/.test(m));
  }

  // Posts are read from Facebook's own timeline responses (captured by hook.js, kept by feed.js).
  // That data holds the full text (no "See more"), the exact time, the author and the counts, so nothing depends on how the page is drawn.
  async function collectPosts(name, max = 10) {
    const feed = window.__scoutwiseFeed;
    if (!feed) throw new Error('Reload this Facebook tab once, then try again.');
    feed.scanScripts(document);
    const y0 = window.scrollY;
    let idle = 0;
    // Scrolling makes Facebook request the next page of posts (3 per request).
    for (let step = 0; step < 14 && feed.count(name) < max && idle < 3; step++) {
      const before = feed.responses;
      window.scrollBy(0, Math.round(window.innerHeight * 0.9));
      await sleep(1500);
      idle = feed.responses === before ? idle + 1 : 0;
    }
    window.scrollTo(0, y0);
    if (!feed.responses) throw new Error('No post data was received from Facebook. Reload this tab and try again.');
    feed.scanScripts(document);
    const posts = feed.list(name, max);
    
    
    if (!posts.length && feed.size()) throw new Error('Facebook sent posts, but none belong to this Page.');
    return posts;
  }

  async function extract() {
    const d = detect();
    if (!d.isProfile) throw new Error('Open the Facebook profile or Page of an author first.');
    if (!d.author) throw new Error('This is not in the Author category.');
    const main = document.querySelector('[role=main]') || document.body;
    const intro = introLines(main);
    const onAbout = /\/about/i.test(location.pathname) || /sk=about/i.test(location.search);
    const ls = onAbout ? lines(main.innerText).slice(0, 400) : intro;
    const info = parseInfo(ls);
    const head = (main.innerText || '').slice(0, 8000);
    const stats = {
      followers: countOf(main, 'followers') || num(head, /([\d.,]+\s?[KMB]?)\s+followers\b/i),
      following: countOf(main, 'following') || num(head, /([\d.,]+\s?[KMB]?)\s+following\b/i),
      friends: countOf(main, 'friends') || num(head, /([\d.,]+\s?[KMB]?)\s+friends\b/i),
    };
    for (const k in stats) if (stats[k]) info[k] = stats[k];
    const meta = document.querySelector('meta[property="og:description"]');
    const bio = pickBio(intro) || clean(meta && meta.content).slice(0, 300);
    const emails = findEmails(main, ls);
    if (emails.length > 1) info.emails = emails;
    const posts = await collectPosts(d.name, 10);
    return { url: d.url, name: d.name, kind: d.kind, author: true, bio, info, posts, email: emails[0] || '' };
  }

  chrome.runtime.onMessage.addListener((m, _s, send) => {
    if (m && m.type === 'detect') { send(detect()); return false; }
    if (m && m.type === 'extract') {
      extract().then((profile) => send({ ok: true, profile }), (e) => send({ ok: false, error: e.message }));
      return true;
    }
    return false;
  });

  // Facebook is a single-page app: watch for navigation instead of page loads.
  // While the answer is "still loading" it is checked every second, so the side panel hears the moment the page is ready.
  let last = '';
  let waiting = false;
  setInterval(() => {
    const h1 = document.querySelector('h1');
    const key = location.href + '|' + (h1 ? h1.textContent : '');
    const changed = key !== last;
    if (!changed && !waiting) return;
    last = key;
    const was = waiting;
    waiting = !!detect().loading;
    if (!changed && was === waiting) return;
    try { chrome.runtime.sendMessage({ type: 'pageChanged' }).catch(() => {}); } catch {}
  }, 1000);
})();
