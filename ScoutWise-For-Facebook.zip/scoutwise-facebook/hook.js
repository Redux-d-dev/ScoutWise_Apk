// Runs inside the Facebook page itself (manifest world MAIN, document_start) so it sees the page's own network calls.
// It only forwards the raw text of timeline responses to feed.js, which lives in the extension's isolated world.
(() => {
  if (window.__scoutwiseHook) return;
  window.__scoutwiseHook = true;
  const MARK = 'timeline_list_feed_units';
  const forward = (kind, text) => {
    if (typeof text === 'string' && text.includes(MARK)) window.postMessage({ source: 'scoutwise-feed', kind, text }, location.origin);
  };

  const xhrSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('load', () => {
      try { forward('xhr', this.responseText); } catch {} // responseText throws for non-text response types
    });
    return xhrSend.apply(this, arguments);
  };

  const nativeFetch = window.fetch;
  window.fetch = function () {
    const p = nativeFetch.apply(this, arguments);
    p.then((res) => {
      if (!/text|json|javascript/i.test(res.headers.get('content-type') || '')) return; // never read media
      return res.clone().text().then((t) => forward('fetch', t));
    }).catch(() => {});
    return p;
  };
})();
