import { get, set, update, settings } from './lib/store.js';
import * as B from './lib/serverB.js';
import * as AI from './lib/ai.js';

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const notice = (text) => set('notice', { text, at: Date.now() });
const patch = (urls, fn) => update('prospects', (l) => l.map((p) => (urls.includes(p.url) ? fn(p) : p)), []);

// Keeps the service worker alive during long calls (any extension API call resets its idle timer).
async function alive(fn) {
  const t = setInterval(() => chrome.storage.local.get('notice'), 20000);
  try { return await fn(); } finally { clearInterval(t); }
}

// A restarted worker lost its in-flight AI call: those prospects go back to waiting.
update('prospects', (l) => l.map((p) => (p.status === 'writing' ? { ...p, status: 'waiting' } : p)), []);

async function push(urls) {
  const list = await get('prospects', []);
  for (const p of list.filter((x) => urls.includes(x.url))) {
    await B.saveProspect({
      profileUrl: p.url,
      status: p.status,
      ...(p.subject ? { subject: p.subject, body: p.body } : {}),
    }).catch(() => {});
  }
}

let running = false;
let again = false;
let forced = false; // a "write the rest now" request must survive being made while a run is in progress
async function processQueue(force) {
  if (force) forced = true;
  if (running) { again = true; return; }
  running = true;
  try {
    const n = (await settings()).aiBatch;
    do {
      again = false;
      for (;;) {
        const waiting = (await get('prospects', [])).filter((p) => p.status === 'waiting').reverse();
        if (!waiting.length || (waiting.length < n && !forced)) break;
        const batch = waiting.slice(0, n);
        const urls = batch.map((p) => p.url);
        await patch(urls, (p) => ({ ...p, status: 'writing', error: undefined }));
        try {
          const results = await alive(() => AI.writeMessages(batch));
          await patch(urls, (p) => {
            const r = results.find((x) => x.url === p.url);
            return !r || r.error
              ? { ...p, status: 'failed', error: (r && r.error) || 'No message returned.' }
              : { ...p, status: 'ready', subject: r.subject, body: r.body, error: undefined };
          });
        } catch (e) {
          await patch(urls, (p) => ({ ...p, status: 'failed', error: e.message }));
          await notice('Writing failed: ' + e.message);
          await push(urls);
          forced = false;
          return;
        }
        await push(urls);
      }
      forced = false; // queue drained; no await since the last check, so nothing can slip in between
    } while (again);
  } finally {
    running = false;
  }
}

async function autoSend() {
  const s = await settings();
  const ready = (await get('prospects', [])).filter((p) => p.status === 'ready').length;
  if (ready >= s.batchSize) await sendNow().catch((e) => notice('Auto-send failed: ' + e.message));
}

const pump = (force = false) => processQueue(force).then(autoSend).catch((e) => notice(e.message));

let sending = false;
async function sendNow() {
  if (sending) throw new Error('A send is already in progress.');
  sending = true;
  try {
    const s = await settings();
    if (!s.accountIds.length) throw new Error('Choose at least one sending account in Settings.');
    const ready = (await get('prospects', [])).filter((p) => p.status === 'ready');
    if (!ready.length) throw new Error('Nothing is ready to send.');
    const camp = await alive(() =>
      B.createCampaign({
        name: s.campaignName || 'Facebook scouting',
        instant: true,
        accountIds: s.accountIds,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
        recipients: ready.map((p) => ({
          email: p.email,
          businessName: (p.name || '').slice(0, 100) || undefined,
          subject: p.subject,
          body: p.body,
        })),
      })
    );
    // Cleared only now that the server has accepted the campaign.
    const urls = ready.map((p) => p.url);
    await update('prospects', (l) => l.filter((p) => !urls.includes(p.url)), []);
    for (let i = 0; i < urls.length; i += 500) {
      try { await B.markSent(camp.id, urls.slice(i, i + 500)); }
      catch { await notice('Campaign created, but updating History failed.'); }
    }
    return { id: camp.id, count: ready.length };
  } finally {
    sending = false;
  }
}

async function addProspect(p) {
  const email = String(p.email || '').trim().toLowerCase();
  if (!EMAIL.test(email)) throw new Error('A valid email is required.');
  if ((await get('prospects', [])).some((x) => x.url === p.url)) throw new Error('Already in your list.');
  let prior = null;
  try { prior = (await B.checkProspects([p.url]))[0]; } catch {}
  if (prior && prior.status === 'in_campaign') throw new Error('You already sent this person a campaign.');
  const rec = { ...p, email, status: 'waiting', addedAt: Date.now() };
  await update('prospects', (l) => [rec, ...l], []);
  B.saveProspect({ profileUrl: p.url, name: p.name, email, bio: p.bio, info: p.info, posts: p.posts, status: 'waiting' }).catch(() => {});
  pump(false);
  return true;
}

const handlers = {
  signIn: () => alive(B.signIn),
  signOut: () => B.signOut(),
  accounts: async () => {
    const [sending, ai] = await Promise.allSettled([B.accounts(), AI.accounts()]);
    return {
      sending: sending.value || [],
      ai: ai.value || [],
      errors: [sending.reason && sending.reason.message, ai.reason && ai.reason.message].filter(Boolean),
    };
  },
  add: ({ profile }) => addProspect(profile),
  edit: async ({ url, email, subject, body }) => {
    email = String(email || '').trim().toLowerCase();
    subject = String(subject || '').replace(/[\x00-\x1f\x7f]+/g, ' ').trim().slice(0, 200);
    body = String(body || '').trim();
    if (!EMAIL.test(email)) throw new Error('Enter a valid email.');
    if (!subject || !body) throw new Error('Subject and message cannot be empty.');
    await patch([url], (p) => ({ ...p, email, subject, body, status: 'ready', error: undefined }));
    await push([url]);
    return true;
  },
  remove: async ({ url }) => { await update('prospects', (l) => l.filter((p) => p.url !== url), []); return true; },
  retry: async ({ url }) => { await patch([url], (p) => ({ ...p, status: 'waiting', error: undefined })); pump(true); return true; },
  generate: async () => { pump(true); return true; },
  send: () => alive(sendNow),
  clear: async () => { await set('prospects', []); return true; },
  history: ({ cursor }) => B.listProspects(cursor),
};

chrome.runtime.onMessage.addListener((m, _sender, send) => {
  const h = handlers[m && m.type];
  if (!h) return false;
  Promise.resolve()
    .then(() => h(m))
    .then((data) => send({ ok: true, data }), (e) => send({ ok: false, error: (e && e.message) || String(e) }));
  return true;
});
