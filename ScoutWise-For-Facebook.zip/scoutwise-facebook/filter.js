// Authors-only filter. View only: it hides cards on the page, nothing else is touched. It is controlled from the side panel.
// Works on exactly two routes, and is switched off everywhere else:
//   /search/pages/?q=<query>          (Pages search results)
//   /groups/<id>/members              (group member list)
// A card is kept when its Page category is "Author" (search: line under the name; members: the text before "N people follow this").
// It is applied again to every card Facebook loads while you scroll.
(() => {
  if (window.__scoutwiseFilter) return;

  const HIDE = 'data-sw-hidden';
  const WATERMARK = /\u034f/;
  const USER = 'a[href*="/user/"]';
  let on = false;
  let lastKind = null;
  const seen = new WeakMap(); // card -> { sig, cat }

  function routeKind() {
    const p = location.pathname;
    if (/^\/search\/pages\/?$/.test(p) && (new URLSearchParams(location.search).get('q') || '').trim()) return 'search';
    if (/^\/groups\/[^/]+\/members\/?$/.test(p)) return 'members';
    return null;
  }

  const feedEl = () => document.querySelector('[role=feed]');
  const articlesOf = (feed) => [...feed.querySelectorAll('[role=article]')].filter((a) => !a.parentElement.closest('[role=article]'));
  const holderIn = (card, feed) => {
    let n = card;
    while (n.parentElement && n.parentElement !== feed) n = n.parentElement;
    return n;
  };
  // Group members: one list item per member (the innermost item that links to /groups/<id>/user/<id>).
  const memberCards = () => [...document.querySelectorAll('[role=listitem]')].filter((li) => li.querySelector(USER) && ![...li.querySelectorAll('[role=listitem]')].some((x) => x.querySelector(USER)));

  // Where the cards are, and which element to hide for a card.
  function source(kind) {
    if (kind === 'search') { const feed = feedEl(); return feed ? { members: false, cards: articlesOf(feed), holder: (c) => holderIn(c, feed) } : null; }
    if (kind === 'members') return { members: true, cards: memberCards(), holder: (c) => c };
    return null;
  }

  // Search card:  name / "Author \u00b7 34 followers" / ...
  // Member row:   a Page reads  name / Joined... / Author \u00b7 1,563 people follow this / Follow
  //               a person reads name / Joined... / Add friend
  // Facebook may render the dot as its own line or inside one line, so the text is cut at every dot first.
  function categoryOf(card, members) {
    const link = card.querySelector('a[href]');
    const sig = link ? link.getAttribute('href') : '';
    const hit = seen.get(card);
    if (hit && hit.sig === sig && hit.cat !== null && (!hit.soft || Date.now() - hit.at > 3000)) return hit.cat;
    const lines = String(card.innerText || '').split('\n').map((t) => t.replace(/\s+/g, ' ').trim()).filter((l) => l && l !== 'Facebook' && !WATERMARK.test(l));
    let cat = null; // null = not drawn yet
    if (members) {
      const pieces = lines.flatMap((l) => l.split('\u00b7').map((s) => s.trim()).filter(Boolean));
      const i = pieces.findIndex((l) => /\bfollows? this\b/i.test(l));
      if (i >= 0) cat = i > 0 ? pieces[i - 1].toLowerCase() : '';
      // A person row has no "follow this" line and often no button text at all ("Name / Joined 11 hours ago"); verdict is re-checked for 3s in case the row was still drawing.
      else if (pieces.length >= 2) cat = '';
    } else {
      cat = lines.length >= 2 ? lines[1].split('\u00b7')[0].trim().toLowerCase() : null;
    }
    seen.set(card, { sig, cat, soft: members && cat === '', at: Date.now() });
    return cat;
  }

  function unhideAll() {
    document.querySelectorAll('[' + HIDE + ']').forEach((e) => { e.style.display = ''; e.removeAttribute(HIDE); });
  }

  function apply(src) {
    let total = 0;
    let shown = 0;
    for (const card of src.cards) {
      const cat = categoryOf(card, src.members);
      const holder = src.holder(card);
      if (cat === null) continue;
      total++;
      if (on && cat !== 'author') {
        if (!holder.hasAttribute(HIDE)) { holder.setAttribute(HIDE, '1'); holder.style.display = 'none'; }
      } else {
        if (holder.hasAttribute(HIDE)) { holder.style.display = ''; holder.removeAttribute(HIDE); }
        if (cat === 'author') shown++;
      }
    }
    return { total, shown };
  }

  // Returns the state the side panel shows: kind is null when this page is not a supported list.
  function tick() {
    const kind = routeKind();
    if (kind !== lastKind) { on = false; unhideAll(); lastKind = kind; }
    if (!kind) return { kind: null, on: false, total: 0, shown: 0 };
    const src = source(kind);
    if (!src || !src.cards.length) return { kind, on, total: 0, shown: 0 };
    const counts = apply(src);
    return { kind, on, ...counts };
  }

  window.__scoutwiseFilter = { tick, set: (v) => { on = !!v && !!routeKind(); return tick(); } };

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((m, _s, send) => {
      if (m && m.type === 'filterState') { send(tick()); return false; }
      if (m && m.type === 'filterSet') { send(window.__scoutwiseFilter.set(m.on)); return false; }
      return false;
    });
  }
  setInterval(tick, 700);
})();
