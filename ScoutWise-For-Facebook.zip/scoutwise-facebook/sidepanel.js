import { settings, get, set, DEFAULTS, SERVERS } from './lib/store.js';

const $ = (s) => document.querySelector(s);
const ENT = { 38: '&amp;', 60: '&lt;', 62: '&gt;', 34: '&quot;', 39: '&#39;' };
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ENT[c.charCodeAt(0)]);
const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const CHIP = { waiting: ['faint', 'Waiting'], writing: ['gold', 'Writing…'], ready: ['sage', 'Ready'], failed: ['brick', 'Failed'], in_campaign: ['sage', 'In campaign'] };
const chip = (s) => { const [c, t] = CHIP[s] || CHIP.waiting; return `<span class='chip c-${c}'>${t}</span>`; };
const label = (k) => k.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase());

const S = { session: null, cfg: DEFAULTS, list: [], page: { state: 'other' }, filter: null, fltTab: null, view: 'scout', open: null, editing: false, manual: '', pending: null, accts: null, hist: { items: [], total: 0, cursor: null }, histBusy: false, busy: '', dialog: '', dirty: false };

const call = (type, payload = {}) =>
  new Promise((res) =>
    chrome.runtime.sendMessage({ type, ...payload }, (r) =>
      res(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : r || { ok: false, error: 'No response.' })
    )
  );

let toastTimer;
function toast(text) {
  const t = $('#toast');
  t.textContent = text;
  t.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('on'), 3500);
}

// Server B comes from config.js, so the browser permission for it is asked from there too: once, inside the sign-in click.
async function ensureServerAccess() {
  let origins;
  try { origins = [new URL(SERVERS.b).origin + '/*']; } catch { return false; }
  try {
    return (await chrome.permissions.contains({ origins })) || (await chrome.permissions.request({ origins }));
  } catch {
    return false;
  }
}

async function load() {
  S.session = await get('session', null);
  S.cfg = await settings();
  S.list = await get('prospects', []);
}
const saveCfg = async (p) => { S.cfg = { ...S.cfg, ...p }; await set('settings', S.cfg); };

async function refreshPage() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  let host = '';
  try { host = new URL((tab && tab.url) || '').hostname; } catch {}
  S.filter = null; S.fltTab = null;
  if (!tab || !host.endsWith('facebook.com')) S.page = { state: 'other' };
  else {
    try { S.filter = await chrome.tabs.sendMessage(tab.id, { type: 'filterState' }); S.fltTab = tab.id; } catch {}
    try {
      const d = await chrome.tabs.sendMessage(tab.id, { type: 'detect' });
      S.page = d && d.isProfile
        ? (!d.author ? { state: d.kind === 'page' ? 'notauthor' : 'personal', name: d.name } : { state: 'profile', tabId: tab.id, ...d })
        : { state: d && d.loading ? 'loading' : 'facebook' };
    } catch {
      S.page = { state: 'reload' };
    }
  }
  if (S.pending && S.pending.url !== S.page.url) { S.pending = null; S.manual = ''; }
}

const typing = () => ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement && document.activeElement.tagName);
function softRender() { if (typing()) S.dirty = true; else render(); }

async function loadAccounts() {
  S.accts = null;
  softRender();
  const r = await call('accounts');
  S.accts = r.ok ? r.data : { sending: [], ai: [], errors: [r.error] };
  softRender();
}

async function loadHistory(reset) {
  S.histBusy = true;
  if (reset) S.hist = { items: [], total: S.hist.total, cursor: null };
  softRender();
  const r = await call('history', { cursor: reset ? undefined : S.hist.cursor });
  S.histBusy = false;
  if (r.ok) S.hist = { items: reset ? r.data.items : [...S.hist.items, ...r.data.items], total: r.data.total, cursor: r.data.nextCursor };
  else toast(r.error);
  softRender();
}

// ---- views ---------------------------------------------------------------

const header = () => `<header><div class='wm'>ScoutWise<small>for Facebook</small></div><div class='row'><span class='chip c-sage'>${esc(S.session.user.email)}</span><button class='ico' data-act='logout' title='Sign out'>⎋</button></div></header>`;

const nav = () => `<nav class='tabs'>${[['scout', 'Scout'], ['history', 'History'], ['settings', 'Settings']].map(([v, t]) => `<button class='${S.view === v || (v === 'scout' && S.view === 'detail') ? 'on' : ''}' data-act='tab' data-v='${v}'>${t}</button>`).join('')}</nav>`;

function loginView() {
  return `<div class='login'><div class='wm'>ScoutWise<small>for Facebook</small></div>
  <h1>Scout Facebook,<br>send from ScoutWise.</h1>
  <p class='sub pad'>Sign in with the Google account you use in the ScoutWise app. Your campaigns will appear there.</p>
  <button class='btn mt' data-act='login' ${S.busy === 'login' ? 'disabled' : ''}>${S.busy === 'login' ? 'Signing in…' : 'Continue with Google'}</button></div>`;
}

const msg = (t, s, c) => `<div class='row'><span><b>${t}</b><div class='sub'>${s}</div></span><span class='chip c-faint'>${c}</span></div>`;

function pageCard() {
  const p = S.page;
  if (p.state === 'other') return msg('Open Facebook', 'Open the Facebook profile or Page of an author to start scouting.', 'Idle');
  if (p.state === 'facebook') return msg('Not an author profile', 'Groups, searches and other Facebook areas are ignored.', 'Idle');
  if (p.state === 'personal') return msg('Not an author: ' + esc(p.name), 'Only profiles and Pages in the Author category can be added.', 'Skip');
  if (p.state === 'notauthor') return msg('Not an author: ' + esc(p.name), 'This Page is not in the Author category, so it is ignored.', 'Skip');
  if (p.state === 'loading') return msg('Reading the page…', 'Waiting for the profile to load.', 'Wait');
  if (p.state === 'reload') return msg('Reload this Facebook tab', 'The extension needs one reload of the tab to see it.', 'Reload');
  const head = `<div class='row'><span><b>${esc(p.name)}</b><div class='sub mono'>${esc(p.url.replace('https://www.', ''))}</div></span>${S.list.some((x) => x.url === p.url) ? "<span class='chip c-sage'>Added</span>" : "<span class='chip c-gold'>Profile detected</span>"}</div>`;
  if (S.list.some((x) => x.url === p.url)) return head;
  const pend = S.pending && S.pending.url === p.url ? S.pending : null;
  let extra = '';
  if (pend) extra += `<div class='sub mt'>Read: ${pend.posts.length} post(s) · ${pend.email ? `email found: <b class='mono'>${esc(pend.email)}</b>` : 'no email in Info'}</div>`;
  if (pend && !pend.email) extra += `<div class='lbl tight mt'>Add an email for this person</div><input id='manual' placeholder='name@example.com' value='${esc(S.manual)}'>`;
  const text = S.busy === 'extract' ? 'Reading profile…' : pend && !pend.email ? 'Add with this email' : 'Add to prospects';
  return `${head}${extra}<button class='btn gold mt' data-act='add' ${S.busy ? 'disabled' : ''}>${text}</button>`;
}

const row = (p) => `<div class='item' data-act='open' data-url='${esc(p.url)}'><div class='row'><b>${esc(p.name)}</b>${chip(p.status)}</div><div class='sub mono'>${esc(p.email)}</div></div>`;

const FLT_HELP = 'Works only on a Pages search (facebook.com/search/pages/?q=…) or a group members page (facebook.com/groups/<id>/members).';
function filterSub() {
  const f = S.filter;
  if (!f) return S.page.state === 'reload' ? 'Reload this Facebook tab first.' : S.page.state === 'other' ? 'Open Facebook first. ' + FLT_HELP : FLT_HELP;
  if (!f.kind) return FLT_HELP;
  if (!f.on) return f.kind === 'members' ? 'Group members list detected.' : 'Pages search detected.';
  return f.total ? `Showing ${f.shown} of ${f.total} loaded. Keep scrolling to load more.` : 'Waiting for the list to load. Scroll a little.';
}
function filterCard() {
  const f = S.filter;
  const ok = !!(f && f.kind);
  return `<div class='row'><span><b>Authors only</b><div class='sub' id='fltSub'>${esc(filterSub())}</div></span></div><button class='btn ${ok && f.on ? 'gold' : 'ghost'} mt' data-act='filter' ${ok ? '' : 'disabled'}>${ok && f.on ? 'Show everyone again' : 'Show authors only'}</button>`;
}

function scoutView() {
  const L = S.list;
  const ready = L.filter((p) => p.status === 'ready').length;
  const waiting = L.filter((p) => p.status === 'waiting').length;
  const batch = S.cfg.batchSize;
  const fltOk = !!(S.filter && S.filter.kind);
  const head = `<div class='lbl first'>Current page</div><div class='card'>${pageCard()}</div>`;
  return `${head}
  <div class='lbl'>Filter</div><div class='card${fltOk ? '' : ' off'}'>${filterCard()}</div>
  <div class='lbl'>Queue</div><div class='card'><div class='row'><span><b class='big'>${ready}</b> <span class='sub'>of ${batch} ready to send</span></span><span class='chip c-gold'>${L.length} active</span></div><div class='prog'><i style='width:${Math.min(100, (ready / batch) * 100)}%'></i></div></div>
  <div class='lbl'>Active prospects</div><div class='card flush'>${L.length ? L.map(row).join('') : "<div class='item sub'>Nothing added yet.</div>"}</div>
  <div class='stack'>${waiting ? `<button class='btn ghost' data-act='generate'>Write messages for the remaining ${waiting}</button>` : ''}<button class='btn gold' data-act='askSend' ${ready && !S.busy ? '' : 'disabled'}>${S.busy === 'send' ? 'Sending…' : `Send now (${ready})`}</button></div>`;
}

function detailView() {
  const p = S.list.find((x) => x.url === S.open);
  if (!p) return scoutView();
  const info = p.info || {};
  const kv = Object.entries(info).filter(([k, v]) => k !== 'other' && v).map(([k, v]) => `<span>${esc(label(k))}</span><span>${esc(v)}</span>`).join('');
  const other = (info.other || []).slice(0, 12).map((l) => `<div class='sub'>${esc(l)}</div>`).join('');
  const eng = (x) => [x.time, x.reactions != null ? x.reactions + ' reactions' : '', x.commentCount != null ? x.commentCount + ' comments' : '', x.shareCount != null ? x.shareCount + ' shares' : '', x.viewCount != null ? x.viewCount + ' views' : ''].filter(Boolean).join(' · ');
  const posts = (p.posts || []).map((x) => `<div class='post'>${x.sharedFrom ? `<small>↪ Shared from ${esc(x.sharedFrom)}${x.ownCaption ? ' (their caption)' : ''}</small>` : ''}${esc(x.text)}<small>${esc(eng(x))}</small>${(x.comments || []).map((k) => `<small>💬 ${esc(k.author)}${k.time ? ' (' + esc(k.time) + ')' : ''}: ${esc(k.text)}</small>`).join('')}</div>`).join('') || "<div class='sub'>No posts were read.</div>";
  const hasMsg = p.subject && p.body;
  let body;
  if (hasMsg && S.editing) body = `<div class='card'><div class='lbl tight'>To</div><input id='e-email' value='${esc(p.email)}'><div class='lbl'>Subject</div><input id='e-subject' value='${esc(p.subject)}'><div class='lbl'>Body</div><textarea id='e-body' class='tall'>${esc(p.body)}</textarea></div>`;
  else if (hasMsg) body = `<div class='card'><div class='lbl tight'>To</div><div class='mono'>${esc(p.email)}</div><div class='lbl'>Subject</div><div>${esc(p.subject)}</div><div class='lbl'>Body</div><div class='pre'>${esc(p.body)}</div></div>`;
  else body = `<div class='card sub'>${p.status === 'failed' ? esc(p.error || 'Writing failed.') : 'The message appears here once it is written.'}</div>`;
  const action = hasMsg ? `<button class='chip c-gold btn-chip' data-act='${S.editing ? 'saveEdit' : 'edit'}'>${S.editing ? 'Save' : 'Edit'}</button>` : p.status === 'failed' ? "<button class='chip c-gold btn-chip' data-act='retry'>Retry</button>" : '';
  return `<button class='back' data-act='back'>‹ Back</button>
  <div class='row'><h1>${esc(p.name)}</h1>${chip(p.status)}</div><div class='sub mono'>${esc(p.url)}</div>
  <div class='lbl'>Extracted</div><div class='card'><div class='kv'><span>Email</span><span class='mono'>${esc(p.email)}</span>${kv}</div>${other}</div>
  <div class='lbl'>Recent posts (${(p.posts || []).length})</div><div class='card'>${posts}</div>
  <div class='row mt'><span class='lbl tight'>Message</span>${action}</div>${body}
  <button class='btn red mt' data-act='removeP'>Remove prospect</button>`;
}

function historyView() {
  const h = S.hist;
  const items = h.items.map((x) => `<div class='item'><div class='row'><b>${esc(x.name || x.profileUrl)}</b>${chip(x.status)}</div><div class='sub mono'>${esc(x.profileUrl.replace('https://www.', ''))}</div></div>`).join('') || `<div class='item sub'>${S.histBusy ? 'Loading…' : 'Nothing yet.'}</div>`;
  return `<div class='row'><h1>History</h1><span class='chip c-gold'>${h.total} total</span></div><div class='lbl'>Every prospect you have added</div><div class='card flush'>${items}</div>${h.cursor ? "<button class='btn ghost mt' data-act='moreHist'>Load more</button>" : ''}`;
}

function settingsView() {
  const c = S.cfg;
  const a = S.accts;
  const sending = !a ? "<div class='item sub'>Loading…</div>" : a.sending.length ? a.sending.map((x) => `<label class='acc'><input type='checkbox' data-acc='${esc(x.id)}' ${c.accountIds.includes(x.id) ? 'checked' : ''} ${x.ok ? '' : 'disabled'}><span class='grow'><b class='mono'>${esc(x.email)}</b><div class='sub'>${x.ok ? `${x.usedToday} / ${x.dailyCap} sent today` : 'Reconnect in the ScoutWise app'}</div></span>${x.ok ? '' : "<span class='chip c-brick'>Needs reauth</span>"}</label>`).join('') : "<div class='item sub'>No sending accounts found.</div>";
  const ai = a && a.ai.length ? a.ai.map((x) => `<label class='acc'><input type='checkbox' data-aiacc='${esc(x.id)}' ${(c.aiAccountIds || []).includes(x.id) ? 'checked' : ''} ${x.ok === false ? 'disabled' : ''}><span class='grow'><b>${esc(x.label || x.id)}</b>${x.cooldownSeconds ? `<div class='sub'>Resting for ${Math.ceil(x.cooldownSeconds / 60)} min</div>` : ''}</span>${x.ok === false ? "<span class='chip c-brick'>Unavailable</span>" : ''}</label>`).join('') : "<div class='item sub'>No AI accounts available.</div>";
  const errors = a && a.errors && a.errors.length ? `<div class='note'>${a.errors.map(esc).join('<br>')}</div>` : '';
  const prompts = c.prompts.map((t, i) => `<div class='mb'><div class='row'><span class='lbl tight'>Prompt ${i + 1}</span>${c.prompts.length > 1 ? `<a class='link' data-act='rmPrompt' data-i='${i}'>Remove</a>` : ''}</div><textarea data-prompt='${i}'>${esc(t)}</textarea></div>`).join('');
  return `<h1>Settings</h1>
  <div class='lbl'>Sending accounts</div><div class='card flush'>${sending}</div>${errors}
  <div class='lbl'>AI accounts</div><div class='card flush'>${ai}</div><div class='note'>Only ticked accounts are ever used. List them in the order you want; if one cannot be used, the next ticked one is tried automatically. Do not tick the account that powers your MCP.</div>
  <div class='lbl'>Campaign name</div><div class='card'><input data-cfg='campaignName' value='${esc(c.campaignName)}'><div class='sub'>One name for every send. Messages differ per person.</div></div>
  <div class='lbl'>Batch size</div><div class='card'><input type='number' min='1' max='5000' data-cfg='batchSize' value='${esc(c.batchSize)}'><div class='sub'>Reaching this many ready messages sends them all automatically.</div></div>
  <div class='lbl'>AI prompts (sent in order to start each chat)</div><div class='card'>${prompts}</div><button class='btn ghost mt' data-act='addPrompt'>+ Add prompt</button>
  <div class='lbl'>Storage</div><button class='btn red' data-act='askClear'>Clear everything saved</button>`;
}

function dialog() {
  if (!S.dialog) return '';
  const ready = S.list.filter((p) => p.status === 'ready').length;
  const d = S.dialog === 'send'
    ? { t: 'Send campaign now?', p: `${ready} message${ready === 1 ? '' : 's'} will go out as one campaign, about 10 seconds apart per sending account, using the ${S.cfg.accountIds.length} account(s) you selected. Sent prospects are cleared once the server confirms.`, b: 'Send', a: 'confirmSend', c: 'gold' }
    : { t: 'Clear everything?', p: 'All active prospects and written messages saved in this browser will be deleted. Your History on the server stays.', b: 'Clear', a: 'confirmClear', c: 'red' };
  return `<div class='dim'><div class='dlg'><h3>${d.t}</h3><p>${d.p}</p><div class='row2'><button class='btn ghost' data-act='closeDialog'>Cancel</button><button class='btn ${d.c}' data-act='${d.a}'>${d.b}</button></div></div></div>`;
}

function render() {
  S.dirty = false;
  const app = $('#app');
  if (!S.session) { app.innerHTML = loginView(); return; }
  const body = S.view === 'detail' ? detailView() : S.view === 'history' ? historyView() : S.view === 'settings' ? settingsView() : scoutView();
  app.innerHTML = header() + `<main>${body}</main>` + nav() + dialog();
}

// ---- actions -------------------------------------------------------------

const actions = {
  async login() {
    if (!(await ensureServerAccess())) return toast('Allow access to the ScoutWise server to sign in.');
    S.busy = 'login'; render();
    const r = await call('signIn');
    S.busy = '';
    if (!r.ok) toast(r.error);
    await load(); render();
  },
  async logout() { await call('signOut'); await load(); render(); },
  tab(el) {
    S.view = el.dataset.v; S.editing = false; render();
    if (S.view === 'history') loadHistory(true);
    if (S.view === 'settings') loadAccounts();
  },
  async add() {
    if (S.busy) return;
    S.busy = 'extract'; render();
    try {
      if (!S.pending || S.pending.url !== S.page.url) {
        const r = await chrome.tabs.sendMessage(S.page.tabId, { type: 'extract' });
        if (!r || !r.ok) throw new Error((r && r.error) || 'Could not read the profile.');
        S.pending = r.profile;
        if (!S.pending.author) { S.pending = null; throw new Error('Only authors can be added.'); }
      }
      const email = (S.pending.email || S.manual).trim();
      if (!EMAIL.test(email)) { if (S.manual.trim()) toast('Enter a valid email.'); return; }
      const r = await call('add', { profile: { ...S.pending, email } });
      if (!r.ok) throw new Error(r.error);
      toast(`Added ${S.pending.name}.`);
      S.pending = null; S.manual = '';
    } catch (e) {
      toast(e.message);
    } finally {
      S.busy = ''; await load(); render();
    }
  },
  async filter() {
    if (!S.filter || !S.filter.kind || !S.fltTab) return;
    try { S.filter = await chrome.tabs.sendMessage(S.fltTab, { type: 'filterSet', on: !S.filter.on }); } catch { toast('Reload this Facebook tab, then try again.'); }
    render();
  },
  async generate() { const r = await call('generate'); toast(r.ok ? 'Writing messages…' : r.error); },
  askSend() { S.dialog = 'send'; render(); },
  askClear() { S.dialog = 'clear'; render(); },
  closeDialog() { S.dialog = ''; render(); },
  async confirmSend() {
    S.dialog = ''; S.busy = 'send'; render();
    const r = await call('send');
    S.busy = '';
    toast(r.ok ? `Campaign created with ${r.data.count} recipients. Manage it in the ScoutWise app.` : r.error);
    await load(); render();
  },
  async confirmClear() { S.dialog = ''; const r = await call('clear'); toast(r.ok ? 'Cleared.' : r.error); await load(); render(); },
  open(el) { S.open = el.dataset.url; S.editing = false; S.view = 'detail'; render(); },
  back() { S.view = 'scout'; S.editing = false; render(); },
  edit() { S.editing = true; render(); },
  async saveEdit() {
    const r = await call('edit', { url: S.open, email: $('#e-email').value, subject: $('#e-subject').value, body: $('#e-body').value });
    if (r.ok) { S.editing = false; toast('Saved.'); await load(); render(); } else toast(r.error);
  },
  async removeP() { await call('remove', { url: S.open }); S.view = 'scout'; await load(); render(); },
  async retry() { const r = await call('retry', { url: S.open }); toast(r.ok ? 'Writing again…' : r.error); },
  addPrompt() { return saveCfg({ prompts: [...S.cfg.prompts, ''] }); },
  rmPrompt(el) { return saveCfg({ prompts: S.cfg.prompts.filter((_, i) => i !== +el.dataset.i) }); },
  moreHist() { return loadHistory(false); },
};

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  Promise.resolve(actions[el.dataset.act] && actions[el.dataset.act](el)).catch((err) => toast(err.message));
});

document.addEventListener('input', (e) => { if (e.target.id === 'manual') S.manual = e.target.value; });

document.addEventListener('change', async (e) => {
  const t = e.target;
  if (t.dataset.prompt !== undefined) {
    const prompts = [...S.cfg.prompts];
    prompts[+t.dataset.prompt] = t.value;
    return saveCfg({ prompts });
  }
  if (t.dataset.aiacc) {
    const ids = [...(S.cfg.aiAccountIds || [])];
    const at = ids.indexOf(t.dataset.aiacc);
    if (t.checked && at < 0) ids.push(t.dataset.aiacc);
    if (!t.checked && at >= 0) ids.splice(at, 1);
    return saveCfg({ aiAccountIds: ids });
  }
  if (t.dataset.acc) {
    const ids = new Set(S.cfg.accountIds);
    if (t.checked) ids.add(t.dataset.acc); else ids.delete(t.dataset.acc);
    return saveCfg({ accountIds: [...ids] });
  }
  const k = t.dataset.cfg;
  if (!k) return;
  let v = t.type === 'checkbox' ? t.checked : t.value;
  if (k === 'batchSize') v = Math.min(5000, Math.max(1, parseInt(v, 10) || 100));
  if (k === 'campaignName') v = v.trim() || DEFAULTS.campaignName;
  await saveCfg({ [k]: v });
});

async function boot() {
  await load();
  await refreshPage();
  render();
  chrome.storage.onChanged.addListener(async (ch, area) => {
    if (area !== 'local') return;
    if (ch.notice && ch.notice.newValue) toast(ch.notice.newValue.text);
    await load();
    softRender();
  });
  const sync = async () => { await refreshPage(); softRender(); };
  // A page still "loading" is asked again every 2 seconds, so it never stays stuck.
  setInterval(() => { if (S.page.state === 'loading') sync(); }, 2000);
  chrome.tabs.onActivated.addListener(sync);
  chrome.tabs.onUpdated.addListener((_id, info) => { if (info.status === 'complete' || info.url) sync(); });
  chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'pageChanged') sync(); });
  // Keeps the filter counts live while you scroll Facebook.
  setInterval(async () => {
    if (!S.session || S.view !== 'scout' || !S.fltTab) return;
    let f;
    try { f = await chrome.tabs.sendMessage(S.fltTab, { type: 'filterState' }); } catch { return; }
    if (!f) return;
    const old = S.filter;
    S.filter = f;
    if (!old || old.kind !== f.kind || old.on !== f.on) { softRender(); return; }
    const el = $('#fltSub');
    if (el) el.textContent = filterSub();
  }, 1200);
  document.addEventListener('focusout', () => setTimeout(() => { if (S.dirty && !typing()) render(); }, 0));
}
boot();
