# ScoutWise for Facebook

Load it: Chrome > chrome://extensions > Developer mode > Load unpacked > pick this folder.
Then click the extension icon to open the side panel.

First run:
1. The extension has a fixed ID (lbjkgfiadkgkfnlpdhdeccmbogcgpmgl, from the key in manifest.json). Add https://lbjkgfiadkgkfnlpdhdeccmbogcgpmgl.chromiumapp.org/ to ALLOWED_REDIRECT_PREFIXES in the Server B .env (comma-separated after scoutwise://) and restart Server B. The private key is in Build\keys (keep it out of git and out of this folder).
2. Server addresses are set only in config.js. The browser asks once to allow the ScoutWise server when signing in; the AI server (Chat-Claude) runs on the user's own computer at a localhost address and needs no key because it only answers this extension (LocalGuard).
3. Continue with Google (the account must already exist from the app), then pick the sending accounts and the AI accounts in Settings.

Files:
- background.js: queue, AI batches of 3, send, token handling
- content.js: profile detection and extraction (all Facebook selectors are at the top)
- lib/serverB.js: ScoutWise API client
- lib/ai.js: Server A adapter (the contract is described at the top of the file)
- sidepanel.*: the UI
