// ScoutWise for Facebook - server addresses. This is the ONLY file you edit to change them.
// Save, then reload the extension at chrome://extensions. The browser asks once to allow the new ScoutWise server at sign-in.
//   serverB: the ScoutWise server (the one the mobile app uses): sign-in, campaigns, History.
//   serverA: the AI server. It runs on the user's own computer (Chat-Claude), so this is localhost (any port); it needs no key.
export const CONFIG = {
  serverB: 'https://redux-server-api.onrender.com/scoutwise',
  serverA: 'http://localhost:5315',
};
