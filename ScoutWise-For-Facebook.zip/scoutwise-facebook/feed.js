// Reads posts from Facebook's own timeline data. Two channels carry it:
//  1. network responses forwarded by hook.js: a stream with one JSON object per line. Line 1 holds
//     data.node.timeline_list_feed_units.edges[].node, the next lines hold one Story each in data.node,
//     and the last line holds only page_info;
//  2. the page's own HTML: the first posts are embedded in <script> tags, with the same responses nested inside wrappers.
// Lines or objects of any other kind are ignored.
(function () {
  'use strict';

  const MARK = 'timeline_list_feed_units';
  const clean = (t) => String(t == null ? '' : t).replace(/[\x00-\x1f\x7f]+/g, ' ').replace(/\s+/g, ' ').trim();
  const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
  const dig = (o, path) => {
    let x = o;
    for (const k of path) {
      if (x == null) return undefined;
      x = x[k];
    }
    return x;
  };
  // First value stored under `key` (document order) that passes `ok`.
  function find(o, key, ok) {
    const stack = [o];
    while (stack.length) {
      const x = stack.pop();
      if (!x || typeof x !== 'object') continue;
      if (!Array.isArray(x) && ok(x[key])) return x[key];
      const kids = Array.isArray(x) ? x : Object.values(x);
      for (let i = kids.length - 1; i >= 0; i--) stack.push(kids[i]);
    }
    return undefined;
  }
  const hasCount = (v) => !!v && isNum(v.count);

  class FeedParser {
    static text(t) {
      return String(t || '').split('\n').map(clean).filter(Boolean).join('\n').slice(0, 1500);
    }

    static when(sec) {
      return isNum(sec) ? new Date(sec * 1000).toISOString().slice(0, 16).replace('T', ' ') + ' UTC' : '';
    }

    static isStory(n) {
      return !!n && typeof n === 'object' && !!n.post_id && isNum(n.creation_time);
    }

    static stories(j) {
      const node = dig(j, ['data', 'node']) || dig(j, ['data', 'user']);
      if (!node || typeof node !== 'object') return [];
      const edges = dig(node, ['timeline_list_feed_units', 'edges']);
      if (Array.isArray(edges)) return edges.map((e) => e && e.node).filter(FeedParser.isStory);
      return FeedParser.isStory(node) ? [node] : [];
    }

    // Returns { id, ts, post } with the same post shape the rest of the extension already uses.
    // A story without text returns { id, ts, skipped } instead (an event, a cover photo...).
    static story(s) {
      const content = dig(s, ['comet_sections', 'content', 'story']) || {};
      const att = content.attached_story && typeof content.attached_story === 'object' ? content.attached_story : null;
      const msgOf = (n) => FeedParser.text(dig(n, ['message', 'text']) ?? dig(n, ['comet_sections', 'message', 'story', 'message', 'text']));
      const own = msgOf(content);
      const text = own || (att ? msgOf(att) : '');
      if (!text) return { id: String(s.post_id), ts: s.creation_time, skipped: FeedParser.describe(s) };

      const ufi = dig(s, ['comet_sections', 'feedback', 'story', 'story_ufi_container', 'story', 'feedback_context']) || {};
      const target = ufi.feedback_target_with_context || {};
      const reactionTypes = {};
      const top = find(target, 'top_reactions', (v) => !!v && Array.isArray(v.edges));
      for (const e of (top && top.edges) || []) {
        const name = clean(dig(e, ['node', 'localized_name']));
        if (name && isNum(e.reaction_count)) reactionTypes[name] = e.reaction_count;
      }
      const comments = [];
      for (const item of Array.isArray(ufi.interesting_top_level_comments) ? ufi.interesting_top_level_comments : []) {
        const c = item && item.comment;
        const body = FeedParser.text(dig(c, ['preferred_body', 'text']) ?? dig(c, ['body', 'text'])).replace(/\n/g, ' ').slice(0, 300);
        if (!body) continue;
        comments.push({ author: clean(dig(c, ['author', 'name'])), time: FeedParser.when(c.created_time), text: body });
        if (comments.length === 3) break;
      }
      const author = dig(content, ['actors', 0, 'name']) || dig(s, ['comet_sections', 'context_layout', 'story', 'actors', 0, 'name']) || '';
      const views = dig(s, ['comet_sections', 'feedback', 'story', 'story_ufi_container', 'story', 'view_count']);
      return {
        id: String(s.post_id),
        ts: s.creation_time,
        post: {
          author: clean(author),
          time: FeedParser.when(s.creation_time),
          ...(att ? { shared: true, sharedFrom: clean(dig(att, ['actors', 0, 'name'])), ownCaption: !!own } : {}),
          text,
          reactions: (find(target, 'reaction_count', hasCount) || { count: 0 }).count,
          reactionTypes,
          commentCount: dig(target, ['comment_rendering_instance', 'comments', 'total_count']) ?? 0,
          shareCount: (find(target, 'share_count', hasCount) || { count: 0 }).count,
          ...(isNum(views) ? { viewCount: views } : {}),
          comments,
        },
      };
    }

    // Diagnostic for stories that carry no text: where they keep a message, and whether they share another post.
    static describe(s) {
      const found = {};
      const walk = (o, path) => {
        if (!o || typeof o !== 'object' || path.length > 30) return;
        for (const k of Object.keys(o)) {
          const v = o[k];
          const p = /^\d+$/.test(k) ? path : path.concat(k);
          if (k === 'message' && v && typeof v.text === 'string' && v.text) found[p.join('.')] = v.text.length + ':' + v.text.slice(0, 30);
          else if ((k === 'attached_story' || k === 'style_list') && v) found[p.join('.')] = Array.isArray(v) ? v.join(',') : 'object';
          walk(v, p);
        }
      };
      walk(s, []);
      return found;
    }

    // Network channel: one JSON object per line.
    static parse(text) {
      const out = [];
      for (const raw of String(text || '').split('\n')) {
        const line = raw.trim();
        if (line[0] !== '{') continue;
        let j;
        try { j = JSON.parse(line); } catch { continue; }
        for (const s of FeedParser.stories(j)) out.push(FeedParser.story(s));
      }
      return out;
    }

    // Page channel: the responses sit anywhere inside wrapper objects, so walk the whole tree.
    static fromTree(tree) {
      const out = [];
      const stack = [tree];
      while (stack.length) {
        const x = stack.pop();
        if (!x || typeof x !== 'object') continue;
        if (!Array.isArray(x) && x.data && (typeof x.data.node === 'object' || typeof x.data.user === 'object')) {
          const found = FeedParser.stories(x);
          if (found.length) {
            for (const s of found) out.push(FeedParser.story(s));
            continue;
          }
        }
        for (const v of Array.isArray(x) ? x : Object.values(x)) stack.push(v);
      }
      return out;
    }
  }

  class FeedCollector {
    constructor() {
      this.byId = new Map();
      this.responses = 0;
      this.skipped = new Map();
      this.sources = {};
      this.scriptInfo = [];
      this.seenScripts = new WeakSet();
    }

    add(r) {
      if (r.skipped) {
        if (!this.skipped.has(r.id)) this.skipped.set(r.id, { id: r.id, time: FeedParser.when(r.ts), paths: r.skipped });
        return 0;
      }
      if (this.byId.has(r.id)) return 0;
      this.byId.set(r.id, r);
      return 1;
    }

    ingest(text, kind) {
      this.responses++;
      this.sources[kind || '?'] = (this.sources[kind || '?'] || 0) + 1;
      let added = 0;
      for (const r of FeedParser.parse(text)) added += this.add(r);
      return added;
    }

    // The first posts of a page load are embedded in the HTML. Each script is read once; what was found is kept in scriptInfo.
    scanScripts(doc) {
      let added = 0;
      for (const s of doc.querySelectorAll('script')) {
        const t = s.textContent;
        if (!t || !t.includes(MARK) || this.seenScripts.has(s)) continue;
        this.seenScripts.add(s);
        const info = { type: s.getAttribute('type') || '', chars: t.length, parsed: false, found: 0, head: t.slice(0, 100) };
        this.scriptInfo.push(info);
        let tree;
        try { tree = JSON.parse(t); } catch { continue; }
        info.parsed = true;
        for (const r of FeedParser.fromTree(tree)) {
          info.found++;
          added += this.add(r);
        }
      }
      return added;
    }

    size() { return this.byId.size; }

    // Stories seen without any text that never turned up with text later.
    unread() { return [...this.skipped.values()].filter((x) => !this.byId.has(x.id)); }

    // Newest first, only the posts written by (or shared by) this Page.
    mine(name) {
      const k = clean(name).toLowerCase();
      return [...this.byId.values()].filter((r) => !k || r.post.author.toLowerCase().includes(k)).sort((a, b) => b.ts - a.ts);
    }

    count(name) { return this.mine(name).length; }

    list(name, max) { return this.mine(name).slice(0, max).map((r) => r.post); }
  }

  if (typeof window !== 'undefined' && window.addEventListener && !window.__scoutwiseFeed) {
    const feed = new FeedCollector();
    window.__scoutwiseFeed = feed;
    window.addEventListener('message', (e) => {
      const d = e.data;
      if (e.source !== window || !d || d.source !== 'scoutwise-feed' || typeof d.text !== 'string') return;
      try { feed.ingest(d.text, d.kind); } catch {}
    });
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = { FeedParser, FeedCollector };
})();
